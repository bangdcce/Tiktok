package simple;

/**
 * Simple indented with spaces.
 *
 * @author Andy Wilkinson
 * @since 1.0.0
 */
public class Simple {

    public static void main(String[] args) throws Exception {
        // Main method
    }

}
