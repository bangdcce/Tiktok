new io.spring.format.maven.VerifyApply().verifyNoApply(basedir)
