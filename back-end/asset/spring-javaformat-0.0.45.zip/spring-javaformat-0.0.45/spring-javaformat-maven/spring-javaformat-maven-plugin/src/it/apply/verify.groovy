new io.spring.format.maven.VerifyApply().verify(basedir)
