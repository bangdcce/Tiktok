/* Header */
package example;

/**
 * The Apache header doesn't match.
 *
 * @author Phillip Webb
 */
public class HeaderMustBeMissingButIsNot {

}
