// (c) Somebody 2017-2019

/**
 * A custom header file.
 *
 * @author Phillip Webb
 */
public class HeaderFile {

}
